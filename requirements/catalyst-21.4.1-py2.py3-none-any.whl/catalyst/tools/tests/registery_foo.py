# flake8: noqa


def foo(a, b):
    """Docs? Contribution is welcome."""
    return {"a": a, "b": b}


def bar():
    """Docs? Contribution is welcome."""
    pass


__all__ = ["foo"]
