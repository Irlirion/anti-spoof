# flake8: noqa

from catalyst.contrib.models.cv.encoders.resnet import ResnetEncoder

__all__ = ["ResnetEncoder"]
