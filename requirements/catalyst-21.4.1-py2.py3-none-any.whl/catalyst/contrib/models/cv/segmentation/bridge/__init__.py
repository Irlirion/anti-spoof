# flake8: noqa
from catalyst.contrib.models.cv.segmentation.bridge.core import BridgeSpec
from catalyst.contrib.models.cv.segmentation.bridge.unet import UnetBridge
