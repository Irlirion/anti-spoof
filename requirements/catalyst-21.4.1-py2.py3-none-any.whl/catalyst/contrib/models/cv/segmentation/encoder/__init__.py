# flake8: noqa
from catalyst.contrib.models.cv.segmentation.encoder.core import EncoderSpec
from catalyst.contrib.models.cv.segmentation.encoder.resnet import ResnetEncoder
from catalyst.contrib.models.cv.segmentation.encoder.unet import UnetEncoder
