# flake8: noqa
from catalyst.contrib.models.cv.segmentation.head.core import HeadSpec
from catalyst.contrib.models.cv.segmentation.head.fpn import FPNHead
from catalyst.contrib.models.cv.segmentation.head.unet import UnetHead
