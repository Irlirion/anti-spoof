# flake8: noqa

from catalyst.contrib.data.nifti.reader import NiftiReader
